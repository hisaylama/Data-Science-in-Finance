from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import List
import pandas as pd
import numpy as np
import pickle
import shap
import datetime
import os

# Paths & model
path_python_material = "/Users/hisay/Desktop/dsif11/app-v4/"  # Set this to actual path if needed
model_id = "lr1"
pipeline_path = f"{path_python_material}/models/{model_id}-pipeline.pkl"
#model_id = "lr1"
#pipeline_path = f"{path_python_material}/models/model.pkl"


# Load model pipeline
with open(pipeline_path, "rb") as f:
    loaded_pipeline = pickle.load(f)

# Load training data for SHAP
X_train_scaled_path = f"{path_python_material}/data/2-intermediate/dsif11-X_train_scaled.npy"
X_train_scaled = np.load(X_train_scaled_path)

# SHAP explainer
explainer = shap.LinearExplainer(loaded_pipeline[1], X_train_scaled)
app = FastAPI()
# ---------------------------
# Single Transaction Schema
# ---------------------------
class Transaction(BaseModel):
    transaction_amount: float
    customer_age: int
    customer_balance: float
# ---------------------------
# Feature Importance
# ---------------------------
@app.get("/feature-importance")
def get_feature_importance():
    features = ['transaction_amount', 'customer_age', 'customer_balance']
    importance = loaded_pipeline[1].coef_[0].tolist()
    return {"feature_importance": dict(zip(features, importance))}

# ----------------------------------------
# Batch CSV Upload + Prediction + ....
# -----------------------------------
@app.post("/upload_predict/")

async def upload_predict(file: UploadFile = File(...)):
    # Validate the file extension
    if not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="The uploaded file must be a CSV.")
    
    # Upload the file to a temporary location
    input_path = f"/tmp/{file.filename}"
    with open(input_path, "wb") as buffer:
        buffer.write(await file.read())

    # Read the CSV file
    try:
        df = pd.read_csv(input_path)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to read CSV file: {e}")

    # Check if the required columns are present
    required_cols = ['transaction_amount', 'customer_age', 'customer_balance']
    missing_cols = [col for col in required_cols if col not in df.columns]
    if missing_cols:
        raise HTTPException(status_code=400, detail=f"Missing required columns: {missing_cols}")

    # Predict using the model
    try:
        predictions = loaded_pipeline.predict(df[required_cols])
        pred_proba = loaded_pipeline.predict_proba(df[required_cols])[:, 1]
        df['fraud_prediction'] = predictions
        df['confidence'] = pred_proba.round(5)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to predict: {e}")

    # Save and return file
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    output_path = f"/tmp/fraud_predictions_{timestamp}.csv"
    try:
        df.to_csv(output_path, index=False)
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to save predictions: {e}")         

    return FileResponse(path=output_path, 
                        filename=os.path.basename(output_path), 
                        media_type="text/csv")



# ---------------------------
# Single Prediction + SHAP
# ---------------------------
# @app.post("/predict/")
# def predict(transaction: Transaction):
#     features = ['transaction_amount', 'customer_age', 'customer_balance']
#     data_point = np.array([[getattr(transaction, f) for f in features]])

#     # Prediction and probabilities
#     prediction = int(loaded_pipeline.predict(data_point)[0])
#     confidence = loaded_pipeline.predict_proba(data_point)[0].tolist()

#     # SHAP values
#     shap_vals = explainer.shap_values(data_point).tolist()

#     return {
#         "fraud_prediction": prediction,
#         "confidence": confidence,
#         "shap_values": shap_vals,
#         "features": features
#     }

#REQUIRED_COLUMNS = ['transaction_amount', 'customer_age', 'customer_balance']
#TMP_DIR = "/tmp"
#os.makedirs(TMP_DIR, exist_ok=True)
