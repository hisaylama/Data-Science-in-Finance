api_url = "http://127.0.0.1:8502" #How it's chosesn?
import streamlit as st
import requests
import numpy as np
from PIL import Image
import pandas as pd
import os
import io

#Title of the app
st.title("Fraud Detection App")

# Display site header
IMAGE_PATH = "/Users/hisay/Desktop/dsif11/app-v4/images/dsif_header_1.png"
try:
    # Open and display the image
    img = Image.open(IMAGE_PATH)
    st.image(img, use_column_width=True)  # Caption and resizing options
except FileNotFoundError:
    st.error(f"Image not found at {IMAGE_PATH}. Please check the file path.")


#Upload the csv file with the data to be predicted
st.markdown("**1. Upload file**")
uploaded_file = st.file_uploader("*Start with importing the CSV data file", type=['csv'])

if uploaded_file is not None:
    df_input = pd.read_csv(uploaded_file)
    st.write("`Preview uploaded data`", df_input)
    #st.dataframe(df_input)
    
    st.markdown("**2. Exploratory data analysis: Process and feautre engineering**")

    if st.button("Add new column: Transaction amount to customer balance"): 
        try:
            #Engineer a new feature
            if 'transaction_amount' in df_input.columns and 'customer_balance' in df_input.columns:
                df_input['TA_CB'] = df_input['transaction_amount'] / df_input['customer_balance']
                st.write("New feature added: `transaction_amount/customer_balance`", df_input)
        
            else:
                st.write("Please upload a csv file with columns: transaction_amount, customer_age, customer_balance")
        except Exception as e:
            st.error(f"Failed to engineer new feature: {e}")

    #Plot correlation heatmap
    st.markdown("`Correlation heatmap`")
    if st.button("Display correlation between feautres"):
        import seaborn as sns
        import matplotlib.pyplot as plt
        try:
            # Plot correlation heatmap
            fig, ax = plt.subplots()
            df_input['TA_CB'] = df_input['transaction_amount'] / df_input['customer_balance']
            
            df_selected = df_input[['transaction_amount', 'customer_age', 'customer_balance', 'is_fraud', 'TA_CB']]
            sns.heatmap(df_selected.corr(), annot=True, cmap='crest', fmt=".2f")
            st.pyplot(fig)
        except Exception as e:
            st.error(f"Failed to plot correlation heatmap: {e}")
    
    #Select the most correlated features
    df_input['TA_CB'] = df_input['transaction_amount'] / df_input['customer_balance']
    available_features = df_input.columns.tolist()
    selected_features = st.multiselect("Select highly correlated features", options = available_features,
                                       default = ['transaction_amount', 'is_fraud'])
    st.markdown("`Preview the selected feature`") 
    if selected_features:   
        df_input = df_input[selected_features]      
        st.dataframe(df_input.head())
    else:
        st.write("Please select at least one feature")  

    if st.button("Show Fraud vs. Non-Fraud Count"):
        st.markdown("`Bar chart showing the number of fraud vs. non-fraud transactions. Non fraud = 0 and Fraud = 1`")
        import matplotlib.pyplot as plt
        import seaborn as sns
        try:
            fig, ax = plt.subplots()
            sns.countplot(data=df_input, x='is_fraud', palette='Set2')
            #ax.set_xticklabels(['Not Fraud', 'Fraud'])
            ax.set_ylabel("Count")
            ax.set_xlabel("Transaction Type")
            ax.legend(labels=['Not Fraud', 'Fraud'])

            ax.set_title("Number of Fraud vs. Non-Fraud Transactions")
            st.pyplot(fig)
        except Exception as e:
            st.error(f"Failed to plot bar chart: {e}")

    #Display the bar plots with the selected features   
    if st.button("Display individual correlation"):
        st.markdown("`Distribution of selected features`. **Change features in `select feautres`")
        import matplotlib.pyplot as plt
        import seaborn as sns
        if not selected_features:
            st.write("Please select at least one feature")
        else:
            try: 
                if len(selected_features) >1:
                    df_plot = df_input[selected_features]
                    g = sns.PairGrid(df_plot, diag_sharey=False, hue='is_fraud')
                    g.map_diag(sns.histplot, hue=None, color=".3", bins=20)
                    g.map_offdiag(sns.scatterplot, s=3)
                    g.map_lower(sns.kdeplot, levels=4, color=".2")
                    g.add_legend()
                    st.pyplot(g)
                else:
                    for feature in selected_features:
                        fig, ax = plt.subplots()
                        sns.histplot(df_input[feature], kde=True, ax=ax)
                        st.pyplot(fig)
            except Exception as e:
                st.error(f"Failed to plot selected features: {e}")
                  
    st.markdown("**3. Predictions**")

    #Predict on the uploaded data
    if st.button("Run predictions"):
        import matplotlib.pyplot as plot 
        try:
            files = {
            "file": (uploaded_file.name, uploaded_file.getvalue(), "text/csv")
            }
            #df_input = pd.read_csv(uploaded_file)
            response = requests.post(f"{api_url}/upload_predict/", files=files)
            st.markdown("Model requires following feautres -> - `transaction_amount`, `customer_age`, `customer_balance`] ")

            st.markdown("**4. Download the predicted results**")
            if response.status_code == 200:
                st.success("Prediction completed successfully!")
                st.download_button(
                    label="Download Predictions", 
                    data=response.content, 
                    file_name="predictions.csv", 
                    mime="text/csv")
                st.write("`Download predictions in *.csv`")
            else: 
                st.error(f"Prediction failed with status code {response.status_code}")
       
        except requests.exceptions.RequestException as e:
            st.error(f"Failed to fetch prediction: {e}")

     
    st.markdown("**5. Prediction confidence**")


if st.button("Show Prediction Confidence"):
    import matplotlib.pyplot as plt
    try:
        # Upload file
        files = {
            "file": (uploaded_file.name, uploaded_file.getvalue(), "text/csv")
        }

        response = requests.post(f"{api_url}/upload_predict/", files=files)
        st.markdown("**Model requires the following features:** `transaction_amount`, `customer_age`, `customer_balance`")

        if response.status_code == 200:
            try:
                # Parse CSV response (not JSON!)
                csv_data = response.text
                result_df = pd.read_csv(io.StringIO(csv_data))

                st.success("Prediction results loaded successfully!")
                st.dataframe(result_df.head())
                st.text(f"Columns: {list(result_df.columns)}")  # 👈 Shows actual columns

                # # Confidence and Category Calculation
                # confidences = [
                #     row['confidence'] if row['fraud_prediction'] == 1 else 1 - row['confidence']
                #     for _, row in result_df.iterrows()
                # ]
                # categories = [
                #     'Fraudulent' if row['fraud_prediction'] == 1 else 'Not Fraudulent'
                #     for _, row in result_df.iterrows()
                # ]
                # colors = ['red' if cat == 'Fraudulent' else 'green' for cat in categories]
                required_cols = {'fraud_prediction', 'confidence'}

                if required_cols.issubset(result_df.columns):
                    # Compute confidence and category
                    confidences = [
                        row['confidence'] if row['fraud_prediction'] == 1 else 1 - row['confidence']
                        for _, row in result_df.iterrows()
                    ]
                    categories = [
                        'Fraudulent' if row['fraud_prediction'] == 1 else 'Not Fraudulent'
                        for _, row in result_df.iterrows()
                    ]
                    colors = ['red' if cat == 'Fraudulent' else 'green' for cat in categories]

                    # Plot
                    fig, ax = plt.subplots()
                    ax.bar(range(len(confidences)), confidences, color=colors)
                    ax.set_xticks(range(len(categories)))
                    ax.set_xticklabels(categories, rotation=45, ha='right')
                    ax.set_ylabel('Confidence')
                    ax.set_title('Prediction Confidence')
                    st.pyplot(fig)
                else:
                    st.warning("⚠️ Required prediction columns not found in the data.")
                    st.text(f"Available columns: {list(result_df.columns)}")

                
                # confidence = result_df['confidence']

                # if result_df['fraud_prediction'] == 0:
                #     st.write("Prediction: Not fraudulent")
                # else:
                #     st.write("Prediction: Fraudulent")

                # # Confidence Interval Visualization
                # labels = ['Not Fraudulent', 'Fraudulent']
                # fig, ax = plt.subplots()
                # ax.bar(labels, confidence, color=['green', 'red'])
                # ax.set_ylabel('Confidence')
                # ax.set_title('Prediction Confidence')
                # st.pyplot(fig)

                # Plotting
                # fig, ax = plt.subplots()
                # ax.barh(range(len(confidences)), confidences, color=colors)
                # ax.set_xticks(range(len(categories)))
                # ax.set_xticklabels(categories, rotation=45, ha='right')
                # ax.set_ylabel('Confidence')
                # ax.set_title('Prediction Confidence')
                # st.pyplot(fig)

            except Exception as e:
                st.error(f"Failed to parse CSV data: {e}")
                st.text(response.text[:500])  # Show preview
        else:
            st.error(f"API call failed with status code {response.status_code}")
            st.text("Server response:")
            st.text(response.text)

    except requests.exceptions.RequestException as e:
        st.error(f"Connection error: {e}")


      